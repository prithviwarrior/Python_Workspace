s1 = 'Welcome to python'
#print(s1[2:13])
#print(s1[-1:13:-1])	

L = [1,1.1, "Text", [1,2,3]]
print((L[3][1]))
print((L[-2][-1][-1]))  