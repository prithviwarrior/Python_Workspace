import threading
import time

def thread_func(n):
	tid = threading.currentThread().ident
	tname = threading.currentThread().name
	print("child thread id:{}, name:{}".format(tid, tname))
	print("Iam child thread:{}".format(n))
	
		
class MyThread():
	

	def __call__(self, n):
		for i in range(n):
		print("Iam child class:{}".format(n))
		time.sleep(1)
		
print("main thread started")
th1 = threading.Thread(target = thread_func, args=(5,))#tuple argument
th1.start()

th1.join() #to stop main thread from stopping brfore child thread
print("main thread end")
