import re 

print(re.match("[0-9]{5}$","14598778")) #only 5 digit number

print(re.match("[0-9]{5}$","14598778"))

print(re.match("[0-9]{5}$","ABDgvhs@ghffs.com"))
